ToggleTVSet
===========

Toggle the visibility of template variables sets by the value of a template
variable.

Features
--------

See this movie for a short introduction: https://cdn.rawgit.com/Jako/ToggleTVSet/607c7004/docs/introduction.mp4

For more information please read the documentation: http://jako.github.io/ToggleTVSet/.
