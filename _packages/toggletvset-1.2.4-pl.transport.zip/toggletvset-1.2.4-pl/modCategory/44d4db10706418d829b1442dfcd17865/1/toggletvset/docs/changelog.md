Changelog for ToggleTVSet
=========================

- 1.2.4
    - Refactored/Standardized code
- 1.2.3
    - Fixing javascript issues with not valid hide/show tv values
    - Fixing issue with the getTVLabel output filter and not found placeholder name
    - Fixing issue with the getTVNames output filter and not found TV ID
- 1.2.2
    - Fixing toggling more than one set
- 1.2.1
    - Fixing wrong visibility state shown after resource save
    - Compressed javascript
- 1.2.0
    - Clear hidden TVs on toggle

- 1.1.0
    - The toggling TV does not have to be assigned to the template or
      accessible in the template. That way an admin could hide template
      variables on resource base without form customization.

- 1.0.0
    - Initial public package release for MODX Revolution

- 0.0.x
    - Initial release
