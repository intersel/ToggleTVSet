#Contributors

The ToggleTVSet project was started in 2015 by 
[Patrick Percy Blank](https://github.com/pepebe) and was developed further and 
packaged as MODX Extra package by [Thomas Jakobi](https://github.com/jako).
